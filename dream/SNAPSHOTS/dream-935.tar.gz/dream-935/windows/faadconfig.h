#include <memory.h>
#include <string.h>
#define DRM 1
#define DRM_PS 1