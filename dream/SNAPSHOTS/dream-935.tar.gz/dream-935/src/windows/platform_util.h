#ifndef UTIL_H
#define UTIL_H

#include <time.h>

time_t timegm(struct tm* const);

#endif // UTIL_H
