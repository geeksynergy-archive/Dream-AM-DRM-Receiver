#ifndef UTIL_H
#define UTIL_H

#include <time.h>

time_t timegm(const struct tm* const);

#endif // UTIL_H
