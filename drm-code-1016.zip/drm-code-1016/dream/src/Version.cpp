/******************************************************************************\
 * Technische Universitaet Darmstadt, Institut fuer Nachrichtentechnik
 * Copyright (c) 2001-2014
 *
 * Author(s):
 *  Andrea Russo, Julian Cable
 *
 * Description:
 *  Dream program version number
 *
 ******************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
\******************************************************************************/
#include "Version.h"
#include "GlobalDefinitions.h"

const char dream_manufacturer[] = "drea";
#ifdef QT_CORE_LIB
# if QT_VERSION >= 0x050000
const char dream_implementation[] = "Q5";
# elif QT_VERSION >= 0x040000
const char dream_implementation[] = "Q4";
# else
const char dream_implementation[] = "QT";
# endif
#else
const char dream_implementation[] = "CL";
#endif
const int dream_version_major = 2;
const int dream_version_minor = 2;
const int dream_version_patch = 0;
const char dream_version_build[] = "-svn979";

