A set of plugins for ethereal.

To build on Windows using code::blocks

1) copy

   libwireshark.dll
   libglib-2.0-0.dll

from the wireshark directory to the directory where this README.txt file is located.

2) open the dcp.workspace file in code::blocks

3) Activate each project and build it

4) copy the mod.dll and drm-di.dll files to the wireshark plugins directory


