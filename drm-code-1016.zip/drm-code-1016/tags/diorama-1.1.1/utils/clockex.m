function date_vector = clockex

%for compatibility only
%called, if mex-function clockex does not exist!
date_vector = clock;